package main

import (
	"fmt"
	"net/http"
	"io/ioutil"
	"path/filepath"
)

func sendTheAddressOfEachServerToAllServers(arr []string) []string {
	var combinations []string

	for i, a := range arr {
		for j, b := range arr {
			if i != j {				
                                sendGetRequest(a + "?server=" + b)
                                fmt.Println(a + " sending its address to server " + b)
			}
		}
	}

	return combinations
}

func sendGetRequest(url string) error {
	response, err := http.Get(url)
	if err != nil {
		return err
	}

	defer response.Body.Close()

	if response.StatusCode != http.StatusOK {
		return fmt.Errorf("Request failed with status code: %d", response.StatusCode)
	}

	return nil
}

func readFilesInDirectory(directoryPath string) ([]string, error) {
	var fileContents []string

	files, err := ioutil.ReadDir(directoryPath)
	if err != nil {
		return nil, err // Return the error if ioutil.ReadDir fails
	}

	for _, file := range files {
		if file.IsDir() {
			continue
		}

		filePath := filepath.Join(directoryPath, file.Name())

		content, err := ioutil.ReadFile(filePath)
		if err != nil {
			return nil, err // Return the error if ioutil.ReadFile fails
		}

		fileContents = append(fileContents, string(content))
	}

	return fileContents, nil
}

func main() {

        // You can use a array with servers instead of open it from text files
	//arr := []string{"http://google.com", "http://localhost.com", "http://test.com"}

        fileContents, err := readFilesInDirectory("servers")
	if err != nil {
		fmt.Println("Error:", err)
		return
	}

        sendTheAddressOfEachServerToAllServers(fileContents)
}
