package main

import (
	"fmt"
	"net/http"
)

func checkURLs(urls []string) {
	for _, url := range urls {
		response, err := http.Get(url)
		if err != nil {
			fmt.Printf("URL: %s is offline\n", url)
		} else {
			defer response.Body.Close()
			fmt.Printf("URL: %s is online\n", url)
		}
	}
}

func main() {
	urls := []string{
		"https://www.google.com",
		"https://www.example.com",
		"https://www.nonexistenturl12345.com",
	}

	checkURLs(urls)
}