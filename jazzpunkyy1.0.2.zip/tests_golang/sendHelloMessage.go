package main

import (
	"fmt"
	"io/ioutil"
	"net/http"
)

func sendHelloMessage(urls []string) {
	message := "hello"
	for _, url := range urls {
		response, err := http.Get(url + "?message=" + message)
		if err != nil {
			fmt.Printf("Error sending message to URL %s: %v\n", url, err)
			continue
		}
		defer response.Body.Close()

		body, err := ioutil.ReadAll(response.Body)
		if err != nil {
			fmt.Printf("Error reading response body from URL %s: %v\n", url, err)
			continue
		}

		fmt.Printf("Response from URL %s: %s\n", url, string(body))
	}
}

func main() {
	urls := []string{
		"https://www.example.com",
		"https://www.google.com",
	}

	sendHelloMessage(urls)
}
