﻿<?php

/*/

In case the user searches for synonymous words or words from a similar category,
they will be redirected to a select default page.

/*/

// Sample input array
$inputArray = array("file1", "file2", "file3");

// Variable to be written inside the files
$targetPage = "test.html";

// Directory to save the files
$directory = "contents/";

$JScontents = "redirecting...
<script>
function redirectToPage() {   
    var destinationURL = '$targetPage';
    
    setTimeout(function() {
        window.location.href = destinationURL;
    }, 2000);
}
redirectToPage();
</script>";

// Loop through the input array
foreach ($inputArray as $element) {
    // Create a new HTML file with the array element plus ".html" inside the "contents" folder
    $fileName = $directory . $element . ".html";
    
    // Open the file in write mode and write the variable value inside the file
    $file = fopen($fileName, "w");
    if ($file) {
        fwrite($file, $JScontents);
        fclose($file);
        echo "File $fileName created successfully.<br>";
    } else {
        echo "Error creating file $fileName.<br>";
    }
}
?>

<script>
function redirectToPage() {   
    var destinationURL = 'destination-page.html';
    
    setTimeout(function() {
        window.location.href = destinationURL;
    }, 2000);
}
redirectToPage();
</script>