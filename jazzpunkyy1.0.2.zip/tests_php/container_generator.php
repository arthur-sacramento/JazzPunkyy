﻿<?php
// Define the number of containers you want to generate
$num_containers = 10;

// Loop through the range of container numbers (1 to num_containers)
for ($i = 1; $i <= $num_containers; $i++) {
    echo '
    <div class="container">
        <div class="top-part">
            <img src="thumbnails/'.$i.'-1.jpg" alt="Picture 1">
            <img src="thumbnails/'.$i.'-2.jpg" alt="Picture 2">
        </div>
        <div class="top-part">
            <img src="thumbnails/'.$i.'-3.jpg" alt="Picture 1">
            <img src="thumbnails/'.$i.'-4.jpg" alt="Picture 2">
        </div>
        <div class="bottom-part">
            <a href="files/'.$i.'.mp4" class="pink-button">Play</a>
        </div>
    </div>
    ';
}
?>

