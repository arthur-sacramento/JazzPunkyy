package main

import "fmt"

func generateCombinations(arr []string) []string {
	var combinations []string

	for i, a := range arr {
		for j, b := range arr {
			if i != j {
				combinations = append(combinations, a+b)
			}
		}
	}

	return combinations
}

func main() {
	arr := []string{"1", "2", "3"}
	combinations := generateCombinations(arr)

	for _, combo := range combinations {
		fmt.Println(combo)
	}
}
