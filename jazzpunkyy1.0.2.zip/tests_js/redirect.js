function redirectToPage(destinationURL) {
    setTimeout(function() {
        window.location.href = destinationURL;
    }, 2000);
}