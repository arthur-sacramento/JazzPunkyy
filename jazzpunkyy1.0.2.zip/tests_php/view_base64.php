﻿<?php

/*/
    Check if one base64 file is is valid (testing with a .jpg image file) 

/*/

// A text file in base64 with a image (the contents of duck.jpg must be text not binary file)
echo $chunk_data = file_get_contents("duck.jpg"); 
 
//Depending on the file type you must change the header
$header = 'data:image/jpg;base64;,';

echo "<img src='$header$chunk_data'>";

?>