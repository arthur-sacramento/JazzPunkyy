package main

import (
	"fmt"
	"io/ioutil"
	"net/http"	
	"path/filepath"
)

const serverURL = "http://localhost/hashes"
const localDir = "hashes"

func main() {
	// Read the list of files in the local directory
	files, err := ioutil.ReadDir(localDir)
	if err != nil {
		fmt.Println("Error reading directory:", err)
		return
	}

	// Loop through the files in the local directory
	for _, file := range files {
		fileName := file.Name()
		localFilePath := filepath.Join(localDir, fileName)

		// Check if the file exists on the server
		serverURL := fmt.Sprintf("%s/%s", serverURL, fileName)
		response, err := http.Get(serverURL)
		if err != nil {
			fmt.Printf("Error checking %s: %v\n", fileName, err)
			continue
		}
		defer response.Body.Close()

		if response.StatusCode == http.StatusOK {
			// The file exists on the server, so compare contents
			serverData, err := ioutil.ReadAll(response.Body)
			if err != nil {
				fmt.Printf("Error reading response data for %s: %v\n", fileName, err)
				continue
			}

			localData, err := ioutil.ReadFile(localFilePath)
			if err != nil {
				fmt.Printf("Error reading local file %s: %v\n", fileName, err)
				continue
			}

			if string(localData) == string(serverData) {
				fmt.Printf("File %s exists on the server and has the same contents.\n", fileName)
			} else {
				fmt.Printf("File %s exists on the server but has different contents.\n", fileName)
			}
		} else {
			fmt.Printf("File %s does not exist on the server.\n", fileName)
		}
	}
}
