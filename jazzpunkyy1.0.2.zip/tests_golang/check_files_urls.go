package main

import (
	"fmt"
	"io/ioutil"
	"net/http"
	"path/filepath"
)

var serverURLs = []string{
	"http://localhost/hashes",
	"http://localhost/hashes2",
}

const localDir = "hashes"

func main() {
	// Read the list of files in the local directory
	files, err := ioutil.ReadDir(localDir)
	if err != nil {
		fmt.Println("Error reading directory:", err)
		return
	}

	// Loop through the files in the local directory
	for _, file := range files {
		fileName := file.Name()
		localFilePath := filepath.Join(localDir, fileName)

		// Check the file against each server URL
		for _, serverURL := range serverURLs {
			serverURL := fmt.Sprintf("%s/%s", serverURL, fileName)
			response, err := http.Get(serverURL)
			if err != nil {
				fmt.Printf("Error checking %s on %s: %v\n", fileName, serverURL, err)
				continue
			}
			defer response.Body.Close()

			if response.StatusCode == http.StatusOK {
				// The file exists on the server, so compare contents
				serverData, err := ioutil.ReadAll(response.Body)
				if err != nil {
					fmt.Printf("Error reading response data for %s on %s: %v\n", fileName, serverURL, err)
					continue
				}

				localData, err := ioutil.ReadFile(localFilePath)
				if err != nil {
					fmt.Printf("Error reading local file %s: %v\n", fileName, err)
					continue
				}

				if string(localData) == string(serverData) {
					fmt.Printf("File %s exists on %s and has the same contents.\n", fileName, serverURL)
				} else {
					fmt.Printf("File %s exists on %s but has different contents.\n", fileName, serverURL)
				}
			} else {
				fmt.Printf("File %s does not exist on %s.\n", fileName, serverURL)
			}
		}
	}
}
