JazzPunkyy - by eXthothem
--------------------------

You are free to use and edit this software as long as it's not for commercial purposes.

We do not take responsibility for the actions by third parties or by users using our application.
Additionally, we do not provide any guarantees about the security or integrity of the data and user system.

For more information and updated terms, please contact:

Contact
exthothem@gmail.com
https://t.me/jazzpunkyy

Freelancer and consultancy
http://wa.me/5591983608861
https://www.linkedin.com/in/arthur-sacramento-a55003230
https://www.upwork.com/freelancers/~01259cc727c8fcdfb6
https://www.fiverr.com/arthursacrament